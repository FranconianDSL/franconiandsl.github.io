# Data Creation with TimeGAN

This library mocks data of a fictional online shop. For this task, a TimeGAN is trained via a kaggle dataset

